# -*- coding: utf-8 -*-
from __future__ import print_function

import re
import sys

from enigma import eDVBDB, eServiceReference

from . import _

# ===== Python version flags =====
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

# ===== Flag for new service detection =====
FLAG_SERVICE_NEW_FOUND = 64


# ===== Parser class for lamedb =====
class SSULameDBParser:
    # Constructor with filename
    def __init__(self, filename):
        self.filename = filename
        self.version = 4
        self.services = {}
        self.transponders = {}
        self.parse(self.load())

    # ===== Normalize hex values while keeping zero safe =====
    @staticmethod
    def _stripLeadingZeros(value):
        value = re.sub("^0+", "", value or "")
        return value or "0"

    # ===== Load lamedb file =====
    def load(self):
        lamedb_file = None
        lines = None
        try:
            # Print info message
            print("[ServiceScanUpdates] Reading file: " + self.filename)
            if PY2:
                # Use simple method for Python 2.7
                lamedb_file = open(self.filename, "r")
                lines = lamedb_file.readlines()
            else:
                # In Python 3, try utf-8 first, then latin-1 as alternative
                try:
                    lamedb_file = open(self.filename, "r", encoding="utf-8", errors="ignore")
                    lines = lamedb_file.readlines()
                    lamedb_file.close()
                    lamedb_file = None
                except (UnicodeDecodeError, LookupError):
                    # If utf-8 fails, try latin-1
                    lamedb_file = open(self.filename, "r", encoding="latin-1", errors="ignore")
                    lines = lamedb_file.readlines()

            if lines and len(lines) > 0:
                if lines[0].find("/3/") != -1:
                    self.version = 3
                elif lines[0].find("/4/") != -1:
                    self.version = 4
                else:
                    lines = None
                    print("[ServiceScanUpdates] Unsupported lamedb version")
            else:
                print("[ServiceScanUpdates] Unsupported lamedb version")
                lines = None
                print("[ServiceScanUpdates] Empty lamedb file")
        except Exception as e:
            print("[ServiceScanUpdates] Exception loading lamedb: " + str(e))
            import traceback
            traceback.print_exc()
            lines = None
        finally:
            if lamedb_file and not lamedb_file.closed:
                lamedb_file.close()

        return lines

    # ===== Parse file content =====
    def parse(self, lines):
        if lines is None:
            return

        reading_transponders = False
        reading_services = False
        tmp = []
        self.transponders = {}
        self.services = {}

        print("[ServiceScanUpdates] Parsing content of file: " + self.filename)
        for line in lines:
            line = line.rstrip("\n\r")

            # Got END tag.
            if line == "end":
                reading_transponders = False
                reading_services = False
                continue

            # Got START tag for: transponders.
            if line == "transponders":
                reading_transponders = True
                reading_services = False
                tmp = []
                continue

            # Got START tag for: services.
            if line == "services":
                reading_services = True
                reading_transponders = False
                tmp = []
                continue

            # ===== Parse transponder lines =====
            # Read data for: transponders.
            # 1 - 00820000:1ce8:0071
            # 2 - s 12188000:27500000:1:4:130:2:0
            if reading_transponders:
                if line == "/":
                    if len(tmp) >= 2:
                        self.transponders[tmp[0]] = tmp[1].replace("\t", "").replace(" ", ":")
                    tmp = []
                elif line:
                    tmp.append(line)
                continue

            # ===== Parse service lines =====
            # Read data for: services.
            # 1 - 2889:00c00000:040f:0001:25:0:0
            # 2 - ARD-alpha HD
            # 3 - p:ARD,C:0000
            if reading_services:
                if line.startswith("p:"):
                    if len(tmp) < 2:
                        tmp = []
                        continue

                    key = tmp[0].split(":")
                    if len(key) == 6:
                        service_id, dvb_namespace, transport_stream_id, original_network_id, service_type, service_number = tmp[0].split(":")
                    elif len(key) == 7:
                        service_id, dvb_namespace, transport_stream_id, original_network_id, service_type, service_number, source_id = tmp[0].split(":")
                    else:
                        tmp = []
                        continue

                    transponder = dvb_namespace + ":" + service_id + ":" + original_network_id

                    # Strip leading 0 from hex strings.
                    service_id = self._stripLeadingZeros(service_id)
                    dvb_namespace = self._stripLeadingZeros(dvb_namespace)
                    transport_stream_id = self._stripLeadingZeros(transport_stream_id)
                    original_network_id = self._stripLeadingZeros(original_network_id)

                    try:
                        service_type = str(hex(int(service_type))).lower()
                    except Exception:
                        tmp = []
                        continue

                    service_type = self._stripLeadingZeros(service_type[2:len(service_type)])
                    service_ref = "1:0:" + service_type.upper() + ":" + service_id.upper() + ":" + transport_stream_id.upper() + \
                                  ":" + original_network_id.upper() + ":" + dvb_namespace.upper() + ":0:0:0:"

                    self.services[service_ref] = {
                        "service_id": service_id,  # Service id (SSID value from stream) in Hex.
                        "dvb_namespace": dvb_namespace,  # DVB namespace in Hex.
                        "transport_stream_id": transport_stream_id,  # Transport stream id in Hex.
                        "original_network_id": original_network_id,  # Original network id in Hex.
                        "service_type": service_type,  # Service type.
                        "service_number": service_number,  # Service number in Decimal.
                        "transponder": transponder,  # Transponder.
                        "service_name": tmp[1],  # Service name.
                    }

                    # Split and parse provider data.
                    provdata = []
                    tmpprovdata = line.split(",")
                    for tmpdata in tmpprovdata:
                        psdata = tmpdata.split(":")
                        if len(psdata) < 2:
                            continue
                        if psdata[0] == "p":
                            self.services[service_ref]["provider"] = psdata[1]
                        else:
                            data = {}
                            # Strip leading 0 of hex fields.
                            psdata[1] = self._stripLeadingZeros(psdata[1])
                            data[psdata[0]] = psdata[1]
                            provdata.append(data)
                    self.services[service_ref]["provider_data"] = provdata
                    tmp = []
                # print('[ServiceScanUpdates] lamedb entry: ' + str(self.services[service_ref]))
                elif line:
                    tmp.append(line)

    # ===== Retrieve a service by reference =====
    def getServiceBySRef(self, service_ref):
        try:
            return self.services[service_ref]
        except Exception:
            return None

    # ===== Retrieve all services =====
    def getServices(self):
        return self.services

    # ===== Get service type from reference =====
    def getServiceName(self, service_ref):
        try:
            return self.services[service_ref]["service_name"]
        except Exception:
            return None

    @staticmethod
    def isVideoService(service_ref):
        service_type_str = str(service_ref.split(":")[2])
        if service_type_str:
            service_type = int(service_type_str, 16)
            print("[ServiceScanUpdates] Check isVideoService [%s] (%d)" % (service_ref, service_type))
            # SD-Video or HD-Video
            return service_type in (1, 4, 5, 6, 11, 17, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31)
        else:
            return False

    @staticmethod
    def isRadioService(service_ref):
        service_ref_str = str(service_ref.split(":")[2])
        if service_ref_str:
            service_type = int(service_ref_str, 16)
            print("[ServiceScanUpdates] Check isRadioService [%s] (%d)" % (service_ref, service_type))
            # Radio
            return service_type in (2, 10)
        else:
            return False

    # ===== Check if service is data =====
    @staticmethod
    def isDataService(service_ref):
        service_ref_str = str(service_ref.split(":")[2])
        if service_ref_str:
            service_type = int(service_ref_str, 16)
            print("[ServiceScanUpdates] Check isDataService [%s] (%d)" % (service_ref, service_type))
            # Data
            return service_type in (3, 12, 13, 14, 15, 16, 128, 129)
        else:
            return False

    # ===== Check if service has new flag =====
    @staticmethod
    def hasNewFlag(service_ref):
        return eDVBDB.getInstance().getFlag(eServiceReference(str(service_ref))) & FLAG_SERVICE_NEW_FOUND

    @staticmethod
    def getOrbitalPos(service_ref):
        try:
            while True:
                op = int(str(service_ref).split(":", 10)[6][:-4] or "0", 16)
                if op == 0xeeee:
                    result = "%s" % _("DVB-T")
                    break
                if op == 0xffff:
                    result = "%s" % _("DVB-C")
                    break

                direction = "E"
                if op > 1800:
                    op = 3600 - op
                    direction = "W"

                # Use ASCII-only orbital formatting to avoid encoding issues in bouquet files.
                result = "%d.%d%s" % (op // 10, op % 10, direction)
                break
        except Exception:
            result = "Unknown"
        print("[ServiceScanUpdates] Orbital pos [%s] (%s)" % (str(service_ref), result))
        return result
