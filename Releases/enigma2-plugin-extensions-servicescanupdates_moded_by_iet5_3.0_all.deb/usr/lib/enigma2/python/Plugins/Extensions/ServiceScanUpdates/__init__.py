# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import gettext

from Components.config import config, ConfigSubsection, ConfigYesNo
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE

PluginLanguageDomain = "ServiceScanUpdates"

PY2 = sys.version_info[0] == 2
PY3 = not PY2


# ===== Resolve the plugin base path dynamically =====
def getPluginBasePath():
    candidates = [
        resolveFilename(SCOPE_PLUGINS, "Extensions/%s" % PluginLanguageDomain),
        resolveFilename(SCOPE_PLUGINS, "SystemPlugins/%s" % PluginLanguageDomain),
    ]
    for candidate in candidates:
        if os.path.isdir(candidate):
            return candidate
    return candidates[0]


PLUGIN_BASE_PATH = getPluginBasePath()
PluginLanguagePath = os.path.join(PLUGIN_BASE_PATH, "locale")


# ===== Build an absolute path inside the plugin folder =====
def pluginResourcePath(*parts):
    return os.path.join(PLUGIN_BASE_PATH, *parts)


# ===== Open text files in a Python 2 / Python 3 compatible way =====
def openTextFile(path, mode, encoding="utf-8"):
    if PY2:
        return open(path, mode)
    return open(path, mode, encoding=encoding)


# ===== Read a text file safely with fallback encodings =====
def readTextFile(path, default_value="", encodings=None):
    if not path or not os.path.exists(path):
        return default_value

    if encodings is None:
        encodings = ("utf-8", "latin-1")

    if PY2:
        try:
            with open(path, "r") as handle:
                return handle.read()
        except Exception:
            return default_value

    for encoding in encodings:
        try:
            with open(path, "r", encoding=encoding, errors="ignore") as handle:
                return handle.read()
        except Exception:
            pass
    return default_value


# ===== Initialize plugin settings if they don't exist =====
def initConfig():
    if not hasattr(config.plugins, "servicescanupdates"):
        config.plugins.servicescanupdates = ConfigSubsection()
        config.plugins.servicescanupdates.add_new_tv_services = ConfigYesNo(default=True)
        config.plugins.servicescanupdates.add_new_radio_services = ConfigYesNo(default=True)
        config.plugins.servicescanupdates.always_create_bouquet = ConfigYesNo(default=False)
        config.plugins.servicescanupdates.create_removed_services_file = ConfigYesNo(default=False)
        config.plugins.servicescanupdates.clear_bouquet = ConfigYesNo(default=False)
    return config.plugins.servicescanupdates


# ===== Try to identify the box model =====
def getBoxModel():
    model_candidates = (
        "/proc/stb/info/model",
        "/proc/stb/info/boxtype",
        "/proc/stb/info/vumodel",
    )
    for candidate in model_candidates:
        value = readTextFile(candidate, "").strip()
        if value:
            return value.lower()
    return ""


# ===== Try to identify the running image / distro =====
def getImageName():
    distro_sources = (
        "/etc/image-version",
        "/etc/issue",
        "/etc/os-release",
        "/etc/vtiversion.info",
    )
    chunks = []
    for candidate in distro_sources:
        value = readTextFile(candidate, "").strip()
        if value:
            chunks.append(value.lower())
    return " ".join(chunks)


# ===== Function to check if running on DreamOS =====
def isDreamOS():
    image_name = getImageName()
    box_model = getBoxModel()

    if "dreamos" in image_name or "dreambox" in image_name:
        return True
    if box_model.startswith("dm") and ("oe2.5" in image_name or "oe2.6" in image_name):
        return True

    try:
        from enigma import eMediaDatabase
        return eMediaDatabase is not None
    except Exception:
        return False


# ===== Build a runtime profile used by condition checks =====
def getRuntimeProfile():
    image_name = getImageName()
    box_model = getBoxModel()
    return {
        "python_version": sys.version.split()[0],
        "python_major": sys.version_info[0],
        "dreamos": isDreamOS(),
        "dreambox": box_model.startswith("dm") or "dreambox" in image_name,
        "vuplus": box_model.startswith("vu") or "vu+" in image_name or "vuplus" in image_name,
        "vti": "vti" in image_name,
        "openatv": "openatv" in image_name,
        "openpli": "openpli" in image_name,
        "openspa": "openspa" in image_name,
        "openvix": "openvix" in image_name,
        "openhdf": "openhdf" in image_name or "hdf" in image_name,
        "image_name": image_name,
        "box_model": box_model,
    }


# ===== DreamOS does not accept font= in some menu/config list widgets =====
def shouldAvoidWidgetFonts():
    return isDreamOS()


# ===== Initialize locale =====
def localeInit():
    lang = language.getLanguage()[:2]
    os.environ["LANGUAGE"] = lang
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)


# ===== Translation function =====
def _(txt):
    translated = gettext.dgettext(PluginLanguageDomain, txt)
    if translated == txt:
        translated = gettext.gettext(txt)
    return translated


# ===== Initialize translation immediately at plugin start =====
localeInit()

# ===== Ensure plugin settings exist immediately =====
initConfig()

# ===== Register callback only if the image supports it safely =====
if not isDreamOS() and hasattr(language, "addCallback"):
    # fixed: pass function, don't call it
    language.addCallback(localeInit)
