# -*- coding: utf-8 -*-
# Developer   : MacDisein
# Modified by : iet5

from __future__ import print_function

import os
import sys
import time
import traceback
from datetime import datetime
from collections import defaultdict

from Plugins.Plugin import PluginDescriptor
from Components.config import config
from Tools.Directories import resolveFilename, SCOPE_CONFIG
from Screens.MessageBox import MessageBox

# Compatible import for ServiceScan
try:
    from Screens.ServiceScan import ServiceScan  # preferred location
except ImportError:
    try:
        from Components.ServiceScan import ServiceScan  # fallback
    except ImportError:
        ServiceScan = None

from . import _, PY2, getRuntimeProfile, initConfig, openTextFile
from .SSULameDBParser import SSULameDBParser
from .SSUBouquetHandler import SSUBouquetHandler

PY3 = sys.version_info[0] == 3
PLUGIN_RUNTIME_PROFILE = getRuntimeProfile()

# Global variables for pre-scan and scan state
baseServiceScan_execBegin = None
baseServiceScan_execEnd = None
preScanDB = None
scan_in_progress = False


# Initialize plugin settings if they don't exist
def init_config():
    return initConfig()


# Check if dictionary has key in Python 2/3 compatible way
def dictHasKey(dictionary, key):
    return key in dictionary


# Safely call the base execEnd with whichever signature is supported
def callBaseExecEnd(self, onClose):
    if baseServiceScan_execEnd is None:
        print("[ServiceScanUpdates] baseServiceScan_execEnd is None")
        return

    try:
        # Try to call the function without onClose first
        baseServiceScan_execEnd(self)
        return
    except TypeError:
        pass
    except Exception as e:
        print("[ServiceScanUpdates] Error calling base execEnd without onClose: %s" % str(e))

    try:
        # If it fails, try with onClose
        baseServiceScan_execEnd(self, onClose)
    except Exception as e:
        print("[ServiceScanUpdates] Error calling base execEnd with onClose: %s" % str(e))


# Resolve the best path for the removed services report
def getRemovedServicesFilePath():
    preferred_dirs = (
        "/media/hdd",
        "/media/usb",
        "/media/mmc",
        resolveFilename(SCOPE_CONFIG),
    )
    for directory in preferred_dirs:
        if directory and os.path.isdir(directory):
            return os.path.join(directory, "removed_services.txt")
    return os.path.join(resolveFilename(SCOPE_CONFIG), "removed_services.txt")


# Read a report file in a safe and compatible way
def readReportLines(path):
    if PY2:
        with open(path, "r") as handle:
            return handle.readlines()
    with openTextFile(path, "r", encoding="utf-8") as handle:
        return handle.readlines()


# Write a report file in a safe and compatible way
def writeReportLines(path, mode, lines):
    if PY2:
        with open(path, mode) as handle:
            if isinstance(lines, list):
                handle.writelines(lines)
            else:
                handle.write(lines)
    else:
        with openTextFile(path, mode, encoding="utf-8") as handle:
            if isinstance(lines, list):
                handle.writelines(lines)
            else:
                handle.write(lines)


# Create or update the removed services report
def updateRemovedServicesFile(preScanServices, postScanServices):
    settings = config.plugins.servicescanupdates
    if not settings.create_removed_services_file.value:
        return

    try:
        datetime_string = datetime.fromtimestamp(time.time()).strftime("%d.%m.%Y - %H:%M")
        removed_file_path = getRemovedServicesFilePath()

        removed_services = defaultdict(list)
        removed_count = 0

        # Search for removed services
        for service_ref in preScanServices.keys():
            if not dictHasKey(postScanServices, service_ref):
                removed_service = preScanServices[service_ref]
                service_name = removed_service.get("service_name", "Unknown Service")
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                entry = "%s (%s)" % (str(service_ref), service_name)
                removed_services[orbital_pos].append(entry)
                removed_count += 1
                print("[ServiceScanUpdates] Removed entry: %s" % entry)

        # If nothing was removed, keep only a short safe history block
        if removed_count == 0 and os.path.exists(removed_file_path):
            lines = readReportLines(removed_file_path)
            writeReportLines(removed_file_path, "w", lines[-50:])

        # Write new removed services
        payload = []
        payload.append("=== Scan at: %s ===\n" % datetime_string)
        payload.append("Total removed services: %d\n" % removed_count)

        if removed_count > 0:
            orbital_positions = list(removed_services.keys())
            orbital_positions.sort()
            for orbital_pos in orbital_positions:
                payload.append("\n--- %s ---\n" % orbital_pos)
                for entry in removed_services[orbital_pos]:
                    payload.append("%s\n" % entry)
        else:
            payload.append("No services were removed in this scan.\n")

        payload.append("=" * 50 + "\n\n")
        writeReportLines(removed_file_path, "a", payload)
        print("[ServiceScanUpdates] Removed services file updated with %d entries at %s" % (removed_count, removed_file_path))

    except Exception as e:
        print("[ServiceScanUpdates] Error creating removed services file: %s" % str(e))
        traceback.print_exc()


# Build dictionaries of new TV and radio services
def collectNewServices(preScanServices, postScanServices):
    newTVServices = defaultdict(list)
    newRadioServices = defaultdict(list)
    new_services_found = 0

    # Detect new services
    for service_ref in postScanServices.keys():
        if dictHasKey(preScanServices, service_ref):
            continue

        new_services_found += 1
        try:
            if SSULameDBParser.isVideoService(service_ref):
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                newTVServices[orbital_pos].append(service_ref)
                print("[ServiceScanUpdates] New TV service: %s" % service_ref)
            elif SSULameDBParser.isRadioService(service_ref):
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                newRadioServices[orbital_pos].append(service_ref)
                print("[ServiceScanUpdates] New Radio service: %s" % service_ref)
        except Exception as e:
            print("[ServiceScanUpdates] Error processing service %s: %s" % (service_ref, str(e)))

    print("[ServiceScanUpdates] Total new services found: %d" % new_services_found)
    return newTVServices, newRadioServices


# Process TV and radio bouquet updates
def updateBouquets(newTVServices, newRadioServices):
    bouquet_handler = SSUBouquetHandler()
    settings = config.plugins.servicescanupdates

    # Process TV services
    tv_count = sum(len(services) for services in newTVServices.values())
    if settings.add_new_tv_services.value and (tv_count > 0 or settings.always_create_bouquet.value):
        try:
            bouquet_handler.addToIndexBouquet("tv")
            if settings.clear_bouquet.value:
                bouquet_handler.createSSUBouquet(newTVServices, "tv")
            elif bouquet_handler.doesSSUBouquetFileExists("tv"):
                bouquet_handler.appendToSSUBouquet(newTVServices, "tv")
            else:
                bouquet_handler.createSSUBouquet(newTVServices, "tv")
            print("[ServiceScanUpdates] TV bouquet processed successfully")
        except Exception as e:
            print("[ServiceScanUpdates] Error creating TV bouquet: %s" % str(e))
            traceback.print_exc()

    # Process Radio services
    radio_count = sum(len(services) for services in newRadioServices.values())
    if settings.add_new_radio_services.value and (radio_count > 0 or settings.always_create_bouquet.value):
        try:
            bouquet_handler.addToIndexBouquet("radio")
            if settings.clear_bouquet.value:
                bouquet_handler.createSSUBouquet(newRadioServices, "radio")
            elif bouquet_handler.doesSSUBouquetFileExists("radio"):
                bouquet_handler.appendToSSUBouquet(newRadioServices, "radio")
            else:
                bouquet_handler.createSSUBouquet(newRadioServices, "radio")
            print("[ServiceScanUpdates] Radio bouquet processed successfully")
        except Exception as e:
            print("[ServiceScanUpdates] Error creating Radio bouquet: %s" % str(e))
            traceback.print_exc()

    # Reload bouquets
    try:
        bouquet_handler.reloadBouquets()
        print("[ServiceScanUpdates] Bouquets reloaded successfully")
    except Exception as e:
        print("[ServiceScanUpdates] Error reloading bouquets: %s" % str(e))
        traceback.print_exc()


# --- ServiceScan execBegin wrapper ---
def ServiceScan_execBegin(self):
    print("[ServiceScanUpdates] ServiceScan_execBegin - Scan started")
    global preScanDB, scan_in_progress

    # Ensure settings are initialized
    init_config()

    # Start scanning
    scan_in_progress = True

    # Load pre-scan database if not already loaded
    settings = config.plugins.servicescanupdates
    if not preScanDB and (settings.add_new_tv_services.value or settings.add_new_radio_services.value):
        try:
            lamedb_path = os.path.join(resolveFilename(SCOPE_CONFIG), "lamedb")
            if os.path.exists(lamedb_path):
                preScanDB = SSULameDBParser(lamedb_path)
                print("[ServiceScanUpdates] Pre-scan database loaded successfully")
                print("[ServiceScanUpdates] Pre-scan services count: %d" % len(preScanDB.getServices()))
            else:
                print("[ServiceScanUpdates] Warning: lamedb file not found at %s" % lamedb_path)
        except Exception as e:
            print("[ServiceScanUpdates] Error loading pre-scan database: %s" % str(e))
            traceback.print_exc()

    if baseServiceScan_execBegin:
        baseServiceScan_execBegin(self)


# --- ServiceScan execEnd wrapper ---
def ServiceScan_execEnd(self, onClose=True):
    global preScanDB, scan_in_progress

    init_config()  # ensure settings initialized

    try:
        settings = config.plugins.servicescanupdates

        # Only if scanning ended and settings are enabled
        if scan_in_progress and preScanDB and (settings.add_new_tv_services.value or settings.add_new_radio_services.value):
            lamedb_path = os.path.join(resolveFilename(SCOPE_CONFIG), "lamedb")
            if os.path.exists(lamedb_path):
                postScanDB = SSULameDBParser(lamedb_path)
                postScanServices = postScanDB.getServices()
                preScanServices = preScanDB.getServices()

                print("[ServiceScanUpdates] Pre-scan services: %d, Post-scan services: %d" %
                      (len(preScanServices), len(postScanServices)))

                # Use all satellites instead of filtering
                newTVServices, newRadioServices = collectNewServices(preScanServices, postScanServices)
                updateBouquets(newTVServices, newRadioServices)
                updateRemovedServicesFile(preScanServices, postScanServices)
            else:
                print("[ServiceScanUpdates] Warning: post-scan lamedb file not found at %s" % lamedb_path)

    except Exception as e:
        print("[ServiceScanUpdates] Error in ServiceScan_execEnd: %s" % str(e))
        traceback.print_exc()
    finally:
        preScanDB = None
        scan_in_progress = False
        print("[ServiceScanUpdates] Scan processing completed")

    # Call the original function
    callBaseExecEnd(self, onClose)


# --- Autostart hook ---
def autostart(reason, **kwargs):
    # Called on session start / autostart
    if reason == 0 and "session" in kwargs:
        # Initialize settings first
        init_config()

        global baseServiceScan_execBegin, baseServiceScan_execEnd

        print("[ServiceScanUpdates] Runtime profile: %s" % str(PLUGIN_RUNTIME_PROFILE))

        # Only proceed if ServiceScan class was found/imported
        if ServiceScan is None:
            print("[ServiceScanUpdates] ServiceScan not available - plugin disabled")
            return

        # Save original methods if not already saved, and wrap them
        try:
            if baseServiceScan_execBegin is None and hasattr(ServiceScan, "execBegin"):
                baseServiceScan_execBegin = ServiceScan.execBegin
                ServiceScan.execBegin = ServiceScan_execBegin
                print("[ServiceScanUpdates] Successfully patched execBegin")
        except Exception as e:
            print("[ServiceScanUpdates] Error patching execBegin: %s" % str(e))
            traceback.print_exc()

        try:
            if baseServiceScan_execEnd is None and hasattr(ServiceScan, "execEnd"):
                baseServiceScan_execEnd = ServiceScan.execEnd
                ServiceScan.execEnd = ServiceScan_execEnd
                print("[ServiceScanUpdates] Successfully patched execEnd")
        except Exception as e:
            print("[ServiceScanUpdates] Error patching execEnd: %s" % str(e))
            traceback.print_exc()


# --- Setup screen opener ---
def open_service_scan_setup(session, **kwargs):
    # Open the setup screen for the plugin
    try:
        from .SSUSetupScreen import SSUSetupScreen
        session.open(SSUSetupScreen)
    except Exception as e:
        print("[ServiceScanUpdates] Failed to open setup screen: %s" % str(e))
        traceback.print_exc()
        try:
            session.open(
                MessageBox,
                _("Unable to open the Service Scan Updates setup screen. Please check the log for details."),
                MessageBox.TYPE_ERROR
            )
        except Exception:
            pass


# --- Menu integration ---
def SSUMenuItem(menuid, **kwargs):
    # Plugin appears in Setup ? Service searching
    if menuid == "scan":
        return [(_("Service Scan Updates"), open_service_scan_setup, "servicescanupdates", None)]
    return []


# --- Plugin registration ---
def Plugins(**kwargs):
    # Register plugin descriptors
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
                         fnc=autostart),
        # Plugin appears in Plugin menu
        PluginDescriptor(name=_("Service Scan Updates"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         icon="plugin.png",
                         fnc=open_service_scan_setup),
        # Plugin appears in Setup ? Service searching (scan menu)
        PluginDescriptor(name=_("Service Scan Updates"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_MENU,
                         fnc=SSUMenuItem)
    ]
