# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import time

from Tools.Directories import fileExists, resolveFilename, SCOPE_CONFIG

from . import PY2, openTextFile


class SSUBouquetHandler:
    SSU_BOUQUET_PREFIX = "userbouquet.ServiceScanUpdates"

    def __init__(self):
        self.service_scan_timestamp = int(time.time())
        self.ssu_bouquet_filepath_prefix = os.path.join(resolveFilename(SCOPE_CONFIG), self.SSU_BOUQUET_PREFIX)

    def reloadBouquets(self):
        try:
            from enigma import eDVBDB
            db_instance = eDVBDB.getInstance()
            db_instance.reloadBouquets()
            if hasattr(db_instance, "reloadServicelist"):
                db_instance.reloadServicelist()
        except Exception as e:
            print("[SSUBouquetHandler] Error reloading bouquets:", str(e))

    def doesSSUBouquetFileExists(self, bouquet_type):
        filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
        return fileExists(filename)

    def _readBouquetLines(self, filename):
        if PY2:
            with open(filename, "r") as handle:
                return handle.readlines()
        with openTextFile(filename, "r", encoding="latin-1") as handle:
            return handle.readlines()

    def _writeBouquetLines(self, filename, lines):
        if PY2:
            with open(filename, "w") as handle:
                handle.writelines(lines)
        else:
            with openTextFile(filename, "w", encoding="latin-1") as handle:
                handle.writelines(lines)

    def _buildBouquetSection(self, services):
        from datetime import datetime

        section_lines = []
        datetime_string = datetime.fromtimestamp(self.service_scan_timestamp).strftime("%d.%m.%Y - %H:%M")
        section_lines.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
        section_lines.append("#DESCRIPTION ------- %s -------\n" % datetime_string)

        orbital_positions = list(services.keys())
        orbital_positions.sort()

        for orbital_pos in orbital_positions:
            service_list = services.get(orbital_pos, [])
            if not service_list:
                continue

            section_lines.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
            section_lines.append("#DESCRIPTION ------- %s -------\n" % orbital_pos)

            seen_services = set()
            for service in service_list:
                if service in seen_services:
                    continue
                seen_services.add(service)
                section_lines.append("#SERVICE %s\n" % service)

        return section_lines

    def addToIndexBouquet(self, bouquet_type):
        try:
            index_file = os.path.join(resolveFilename(SCOPE_CONFIG), "bouquets.%s" % bouquet_type)
            bouquet_line = '#SERVICE 1:7:%d:0:0:0:0:0:0:0:FROM BOUQUET "%s.%s" ORDER BY bouquet\n' % (
                1 if bouquet_type == "tv" else 2, self.SSU_BOUQUET_PREFIX, bouquet_type)

            # enigma2 uses latin-1 encoding for bouquet files
            if PY2:
                if not os.path.exists(index_file):
                    with open(index_file, "w") as f:
                        f.write("#NAME Bouquets (%s)\n" % bouquet_type)

                with open(index_file, "r") as f:
                    content = f.read()

                if bouquet_line not in content:
                    with open(index_file, "a") as f:
                        f.write(bouquet_line)
            else:
                # Python 3: use latin-1 as enigma2 standard
                if not os.path.exists(index_file):
                    with openTextFile(index_file, "w", encoding="latin-1") as f:
                        f.write("#NAME Bouquets (%s)\n" % bouquet_type)

                with openTextFile(index_file, "r", encoding="latin-1") as f:
                    content = f.read()

                if bouquet_line not in content:
                    with openTextFile(index_file, "a", encoding="latin-1") as f:
                        f.write(bouquet_line)

        except Exception as e:
            print("[SSUBouquetHandler] Error adding to index:", str(e))

    def createSSUBouquet(self, services, bouquet_type):
        try:
            content = ["#NAME Service Scan Updates\n"]
            content.extend(self._buildBouquetSection(services))

            total_services = 0
            for service_list in services.values():
                total_services += len(service_list)

            filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
            print("[SSUBouquetHandler] Creating bouquet file: %s with %d services" % (filename, total_services))

            # enigma2 uses latin-1 encoding for bouquet files
            self._writeBouquetLines(filename, content)

            print("[SSUBouquetHandler] Bouquet file created successfully: %s" % filename)

        except Exception as e:
            print("[SSUBouquetHandler] Error creating bouquet:", str(e))
            import traceback
            traceback.print_exc()

    def appendToSSUBouquet(self, services, bouquet_type):
        try:
            filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)

            if not self.doesSSUBouquetFileExists(bouquet_type):
                self.createSSUBouquet(services, bouquet_type)
                return

            # enigma2 uses latin-1 encoding for bouquet files
            old_content = self._readBouquetLines(filename)
            new_content = self._buildBouquetSection(services)

            # Insert new content after name line
            final_content = []
            inserted = False
            for line in old_content:
                final_content.append(line)
                if not inserted and line.strip() == "#NAME Service Scan Updates":
                    final_content.extend(new_content)
                    inserted = True

            if not inserted:
                final_content = ["#NAME Service Scan Updates\n"] + new_content + old_content

            self._writeBouquetLines(filename, final_content)

        except Exception as e:
            print("[SSUBouquetHandler] Error appending to bouquet:", str(e))
