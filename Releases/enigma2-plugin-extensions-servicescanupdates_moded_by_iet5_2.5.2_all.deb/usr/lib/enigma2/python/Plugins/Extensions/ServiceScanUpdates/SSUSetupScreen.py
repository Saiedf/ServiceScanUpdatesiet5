# -*- coding: utf-8 -*-
from __future__ import print_function, division

import os
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo, getConfigListEntry
from Components.Button import Button
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from enigma import getDesktop
from . import _

# ===== Global Variables =====
plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates"

# ===== Version =====
def read_version():
    if not plugin_path:
        return "Unknown version"
    vf = os.path.join(plugin_path, "version.txt")
    try:
        with open(vf, "r") as f:
            return f.read().strip()
    except IOError:
        return "Unknown version"
    except Exception as e:
        print("[ServiceScanUpdates] Error reading version:", str(e))
        return "Unknown version"

version = read_version()

# =====================
# Plugin settings
# =====================
if not hasattr(config.plugins, 'servicescanupdates'):
    config.plugins.servicescanupdates = ConfigSubsection()
    config.plugins.servicescanupdates.add_new_tv_services = ConfigYesNo(default=True)
    config.plugins.servicescanupdates.add_new_radio_services = ConfigYesNo(default=True)
    config.plugins.servicescanupdates.always_create_bouquet = ConfigYesNo(default=False)
    config.plugins.servicescanupdates.create_removed_services_file = ConfigYesNo(default=False)
    config.plugins.servicescanupdates.clear_bouquet = ConfigYesNo(default=False)

# =====================
# SSUSetupScreen
# =====================
class SSUSetupScreen(ConfigListScreen, Screen):
    # ===== Skins =====
    skin_fhd = """<screen name="SSUSetupScreen" position="center,center" size="1200,820" title="" flags="wfNoBorder" backgroundColor="#303030">

    <!-- Header -->
    <widget name="title_left" position="10,5" size="800,40" font="Regular;32" halign="left" valign="center" transparent="1" foregroundColor="white" />
    <widget name="title_right" position="10,5" size="1180,40" font="Regular;32" halign="right" valign="center" transparent="1" foregroundColor="white" />

    <!-- Colored Softkeys Buttons (PNG-based) -->
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates/buttons/red.png"
        position="10,55" size="350,60" scale="stretch" alphatest="on" zPosition="1" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates/buttons/green.png"
        position="370,55" size="350,60" scale="stretch" alphatest="on" zPosition="1" />
    <!-- Buttons -->
    <widget name="key_red" position="10,55" size="350,60"
        font="Regular;32" halign="center" valign="center"
        transparent="1" foregroundColor="white" zPosition="2" />
    <widget name="key_green" position="370,55" size="350,60"
        font="Regular;32" halign="center" valign="center"
        transparent="1" foregroundColor="white" zPosition="2" />
    <!-- Settings divider -->
    <ePixmap pixmap="skin_default/div-h.png" position="10,700" zPosition="2" size="1180,2" />

    <!-- Config area -->
    <widget name="config" position="10,130" itemHeight="50" size="1180,460" font="Regular;32" enableWrapAround="1" scrollbarMode="showOnDemand" />

    <!-- Help area -->
    <widget name="help" position="10,600" size="1180,110" font="Regular;28" />

    <!-- Footer -->
    <widget name="footer" position="10,730" size="1180,60" font="Regular;26" halign="center" valign="center" foregroundColor="#FFD700" />

</screen>
"""

    skin_hd = """<screen name="SSUSetupScreen" position="center,center" size="800,530" title="" flags="wfNoBorder" backgroundColor="#303030">

    <!-- Header -->
    <widget name="title_left" position="10,2" size="500,40" font="Regular;26" halign="left" valign="center" transparent="1" foregroundColor="white" />
    <widget name="title_right" position="10,2" size="780,40" font="Regular;26" halign="right" valign="center" transparent="1" foregroundColor="white" />

    <!-- Colored Softkeys Buttons (PNG-based) -->
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates/buttons/red.png"
        position="10,40" size="250,50" scale="stretch" alphatest="on" zPosition="1" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/ServiceScanUpdates/buttons/green.png"
        position="270,40" size="250,50" scale="stretch" alphatest="on" zPosition="1" />

    <!-- Buttons -->
    <widget name="key_red" position="10,40" size="250,50"
        font="Regular;26" halign="center" valign="center"
        transparent="1" foregroundColor="white" zPosition="2" />
    <widget name="key_green" position="270,40" size="250,50"
        font="Regular;26" halign="center" valign="center"
        transparent="1" foregroundColor="white" zPosition="2" />
    <!-- Settings divider -->
    <ePixmap pixmap="skin_default/div-h.png" position="10,450" zPosition="2" size="780,2" />

    <!-- Config area -->
    <widget name="config" position="10,100" itemHeight="40" size="780,250" enableWrapAround="1" scrollbarMode="showOnDemand" />

    <!-- Help area -->
    <widget name="help" position="10,380" size="780,20" font="Regular;22" />

    <!-- Footer -->
    <widget name="footer" position="10,480" size="780,20" font="Regular;22" halign="center" valign="center" foregroundColor="#FFD700" />

</screen>
"""

    def __init__(self, session):
        self.session = session

        # ===== Choose Skin based on resolution =====
        desktop_size = getDesktop(0).size()
        screen_width = desktop_size.width()
        screen_height = desktop_size.height()
        print("[ServiceScanUpdates] Screen size: {}x{}".format(screen_width, screen_height))

        if screen_width >= 1920 and screen_height >= 1080:
            self.skin = self.skin_fhd  # FHD
        else:
            self.skin = self.skin_hd   # HD or less

        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session)

        # ===== Widgets =====
        self["title_left"] = Label(_("Service Scan Setup"))
        self["title_right"] = Label("v%s" % version)
        self["help"] = Label(_("Configure the update options."))
        self["key_red"] = Button(_("Cancel"))
        self["key_green"] = Button(_("Save"))
        self["footer"] = Label(_("Developer MacDisein -- Modified for Py2 & Py3 by iet5"))
        self["pix_red"] = Label()
        self["pix_green"] = Label()
        self["divider"] = Label()

        # ===== ActionMap =====
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions", "HelpActions"],
            {
                "red": self.keyCancel,
                "green": self.keySave,
                "cancel": self.keyCancel,
                "save": self.keySave,
                "ok": self.keySave,
                "displayHelp": self.showHelp,
            },
            -2
        )

        # Config list setup
        self.onLayoutFinish.append(self.layoutFinished)
        self["config"].onSelectionChanged.append(self.updateHelp)

    # ===== Other Methods =====
    def layoutFinished(self):
        self.populateList()

    def populateList(self):
        self.list = [
            getConfigListEntry(_("Add new TV services"), config.plugins.servicescanupdates.add_new_tv_services, _("Create 'Service Scan Updates' bouquet for new TV services?")),
            getConfigListEntry(_("Add new radio services"), config.plugins.servicescanupdates.add_new_radio_services, _("Create 'Service Scan Updates' bouquet for new radio services?")),
            getConfigListEntry(_("Always create bouquet"), config.plugins.servicescanupdates.always_create_bouquet, _("Always create the 'Service Scan Updates' bouquet, even if no new services were found.")),
            getConfigListEntry(_("Create removed services file"), config.plugins.servicescanupdates.create_removed_services_file, _("Create a file under /media/hdd/ with a list of removed channels?")),
            getConfigListEntry(_("Clear bouquet at each search"), config.plugins.servicescanupdates.clear_bouquet, _("Empty the 'Service Scan Updates' bouquet on every scan, otherwise the new services will be appended?")),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def updateHelp(self):
        cur = self["config"].getCurrent()
        if cur:
            self["help"].text = cur[2]

    def showHelp(self):
        help_txt = _("This plugin creates a favorites bouquet (for TV and Radio) with the name 'Service Scan Updates'.\n")
        help_txt += _("All new services found during the scan are inserted there together with a marker.\n")
        help_txt += _("This allows you to quickly and clearly see which new services were found,\n")
        help_txt += _("and you can add individual services to your own Favorites bouquets as usual.\n\n")
        help_txt += _("In order for the 'Service Scan Updates' bouquet to be displayed,\n")
        help_txt += _("the option 'Allow multiple bouquets' must be activated in the system settings of the box.")
        self.session.open(MessageBox, help_txt, MessageBox.TYPE_INFO)

    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        self.close()

    def keyCancel(self):
        self.close()

# ===== Plugin Entry Points =====
def main(session, **kwargs):
    session.open(SSUSetupScreen)

def menuHook(menuid, **kwargs):
    if menuid == "scan":
        return [(_("Service Scan Updates"), main, "service_scan_updates", None)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=_("Service Scan Updates"),
            description=_("Configure service scan update options"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main
        ),
        PluginDescriptor(
            name=_("Service Scan Updates"),
            description=_("Configure service scan update options"),
            where=PluginDescriptor.WHERE_MENU,
            fnc=menuHook
        )
    ]