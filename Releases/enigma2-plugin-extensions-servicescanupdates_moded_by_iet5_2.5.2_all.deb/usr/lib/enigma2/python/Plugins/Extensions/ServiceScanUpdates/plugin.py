# -*- coding: utf-8 -*-
# Developer   : MacDisein
# Modified by : iet5

from __future__ import print_function

import os
import sys
import shutil
import time
from datetime import datetime
from collections import defaultdict

from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigYesNo
from Tools.Directories import resolveFilename, SCOPE_CONFIG
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop

# Compatible import for ServiceScan
try:
    from Screens.ServiceScan import ServiceScan  # preferred location
except ImportError:
    try:
        from Components.ServiceScan import ServiceScan  # fallback
    except ImportError:
        ServiceScan = None

from . import _
from .SSULameDBParser import SSULameDBParser
from .SSUBouquetHandler import SSUBouquetHandler

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

# Global variables for pre-scan and scan state
baseServiceScan_execBegin = None
baseServiceScan_execEnd = None
preScanDB = None
scan_in_progress = False

# Initialize plugin settings if they don't exist
def init_config():
    if not hasattr(config.plugins, 'servicescanupdates'):
        config.plugins.servicescanupdates = ConfigSubsection()
        config.plugins.servicescanupdates.add_new_tv_services = ConfigYesNo(default=True)
        config.plugins.servicescanupdates.add_new_radio_services = ConfigYesNo(default=True)
        config.plugins.servicescanupdates.always_create_bouquet = ConfigYesNo(default=False)
        config.plugins.servicescanupdates.create_removed_services_file = ConfigYesNo(default=False)
        config.plugins.servicescanupdates.clear_bouquet = ConfigYesNo(default=False)

# Check if dictionary has key in Python 2/3 compatible way
def dictHasKey(dictionary, key):
    return key in dictionary

# Safely close database-like objects
def safeClose(db):
    if hasattr(db, "close"):
        try:
            db.close()
        except Exception:
            pass

# --- ServiceScan execBegin wrapper ---
def ServiceScan_execBegin(self):
    print("[ServiceScanUpdates] ServiceScan_execBegin - Scan started")
    global preScanDB, scan_in_progress

    # Ensure settings are initialized
    init_config()

    # Start scanning
    scan_in_progress = True

    # Load pre-scan database if not already loaded
    if not preScanDB and (config.plugins.servicescanupdates.add_new_tv_services.value or
                          config.plugins.servicescanupdates.add_new_radio_services.value):
        try:
            lamedb_path = os.path.join(resolveFilename(SCOPE_CONFIG), "lamedb")
            if os.path.exists(lamedb_path):
                preScanDB = SSULameDBParser(lamedb_path)
                print("[ServiceScanUpdates] Pre-scan database loaded successfully")
                print("[ServiceScanUpdates] Pre-scan services count: %d" % len(preScanDB.getServices()))
            else:
                print("[ServiceScanUpdates] Warning: lamedb file not found at", lamedb_path)
        except Exception as e:
            print("[ServiceScanUpdates] Error loading pre-scan database:", str(e))

    if baseServiceScan_execBegin:
        baseServiceScan_execBegin(self)

# --- ServiceScan execEnd wrapper ---
def ServiceScan_execEnd(self, onClose=True):
    global preScanDB, scan_in_progress

    init_config()  # ensure settings initialized

    try:
        # Only if scanning ended and settings are enabled
        if scan_in_progress and (config.plugins.servicescanupdates.add_new_tv_services.value or
                                 config.plugins.servicescanupdates.add_new_radio_services.value):
            if preScanDB:
                try:
                    lamedb_path = os.path.join(resolveFilename(SCOPE_CONFIG), "lamedb")
                    if os.path.exists(lamedb_path):
                        postScanDB = SSULameDBParser(lamedb_path)
                        postScanServices = postScanDB.getServices()
                        preScanServices = preScanDB.getServices()

                        print("[ServiceScanUpdates] Pre-scan services: %d, Post-scan services: %d" %
                              (len(preScanServices), len(postScanServices)))

                        # Use all satellites instead of filtering
                        newTVServices = defaultdict(list)
                        newRadioServices = defaultdict(list)

                        # Search for new services - Fix here
                        new_services_found = 0
                        # Detect new services
                        for service_ref in postScanServices.keys():
                            if not dictHasKey(preScanServices, service_ref):
                                new_services_found += 1
                                try:
                                    if SSULameDBParser.isVideoService(service_ref):
                                        orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                                        newTVServices[orbital_pos].append(service_ref)
                                        print("[ServiceScanUpdates] New TV service: %s" % service_ref)
                                    elif SSULameDBParser.isRadioService(service_ref):
                                        orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                                        newRadioServices[orbital_pos].append(service_ref)
                                        print("[ServiceScanUpdates] New Radio service: %s" % service_ref)
                                except Exception as e:
                                    print("[ServiceScanUpdates] Error processing service %s: %s" % (service_ref, str(e)))

                        print("[ServiceScanUpdates] Total new services found: %d" % new_services_found)

                        bouquet_handler = SSUBouquetHandler()

                        # Process TV services
                        tv_count = sum(len(services) for services in newTVServices.values())

                        if config.plugins.servicescanupdates.add_new_tv_services.value and \
                                (tv_count > 0 or config.plugins.servicescanupdates.always_create_bouquet.value):
                            try:
                                bouquet_handler.addToIndexBouquet("tv")
                                if config.plugins.servicescanupdates.clear_bouquet.value:
                                    bouquet_handler.createSSUBouquet(newTVServices, "tv")
                                else:
                                    if bouquet_handler.doesSSUBouquetFileExists("tv"):
                                        bouquet_handler.appendToSSUBouquet(newTVServices, "tv")
                                    else:
                                        bouquet_handler.createSSUBouquet(newTVServices, "tv")
                                print("[ServiceScanUpdates] TV bouquet processed successfully")
                            except Exception as e:
                                print("[ServiceScanUpdates] Error creating TV bouquet: %s" % str(e))

                        # Process Radio services
                        radio_count = sum(len(services) for services in newRadioServices.values())

                        if config.plugins.servicescanupdates.add_new_radio_services.value and \
                                (radio_count > 0 or config.plugins.servicescanupdates.always_create_bouquet.value):
                            try:
                                bouquet_handler.addToIndexBouquet("radio")
                                if config.plugins.servicescanupdates.clear_bouquet.value:
                                    bouquet_handler.createSSUBouquet(newRadioServices, "radio")
                                else:
                                    if bouquet_handler.doesSSUBouquetFileExists("radio"):
                                        bouquet_handler.appendToSSUBouquet(newRadioServices, "radio")
                                    else:
                                        bouquet_handler.createSSUBouquet(newRadioServices, "radio")
                                print("[ServiceScanUpdates] Radio bouquet processed successfully")
                            except Exception as e:
                                print("[ServiceScanUpdates] Error creating Radio bouquet: %s" % str(e))

                        # Reload bouquets
                        try:
                            bouquet_handler.reloadBouquets()
                            print("[ServiceScanUpdates] Bouquets reloaded successfully")
                        except Exception as e:
                            print("[ServiceScanUpdates] Error reloading bouquets: %s" % str(e))

                        # Handle removed services
                        if config.plugins.servicescanupdates.create_removed_services_file.value:
                            try:
                                datetime_string = datetime.fromtimestamp(time.time()).strftime("%d.%m.%Y - %H:%M")
                                removed_file_path = os.path.join("/media/hdd/", "removed_services.txt")

                                removed_services = defaultdict(list)
                                removed_count = 0

                                # Search for removed services
                                for service_ref in preScanServices.keys():
                                    if not dictHasKey(postScanServices, service_ref):
                                        removed_service = preScanServices[service_ref]
                                        service_name = removed_service.get('service_name', 'Unknown Service')
                                        orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                                        entry = '%s (%s)' % (str(service_ref), service_name)
                                        removed_services[orbital_pos].append(entry)
                                        removed_count += 1
                                        print('[ServiceScanUpdates] Removed entry: %s' % entry)

                                # If no new services, remove old scan date
                                if removed_count == 0 and os.path.exists(removed_file_path):
                                    lines = []
                                    if PY2:
                                        with open(removed_file_path, "r") as f:
                                            lines = f.readlines()
                                    else:
                                        with open(removed_file_path, "r", encoding='utf-8') as f:
                                            lines = f.readlines()
                                    # Keep only last scan date block
                                    with open(removed_file_path, "w" if PY2 else "w", encoding='utf-8') as f:
                                        for line in lines[-50:]:  # keep last 50 lines as safe block
                                            f.write(line)

                                # Write new removed services
                                if PY2:
                                    # In Python 2.7, use open without encoding
                                    with open(removed_file_path, "a") as removed_services_file:
                                        removed_services_file.write('=== Scan at: %s ===\n' % datetime_string)
                                        removed_services_file.write('Total removed services: %d\n' % removed_count)

                                        if removed_count > 0:
                                            for op, entries in removed_services.items():
                                                removed_services_file.write('\n--- %s ---\n' % op)
                                                for entry in entries:
                                                    removed_services_file.write('%s\n' % entry)
                                        else:
                                            removed_services_file.write('No services were removed in this scan.\n')
                                        removed_services_file.write('=' * 50 + '\n\n')
                                else:
                                    # In Python 3, use encoding='utf-8'
                                    with open(removed_file_path, "a", encoding='utf-8') as removed_services_file:
                                        removed_services_file.write('=== Scan at: %s ===\n' % datetime_string)
                                        removed_services_file.write('Total removed services: %d\n' % removed_count)

                                        if removed_count > 0:
                                            for op, entries in removed_services.items():
                                                removed_services_file.write('\n--- %s ---\n' % op)
                                                for entry in entries:
                                                    removed_services_file.write('%s\n' % entry)
                                        else:
                                            removed_services_file.write('No services were removed in this scan.\n')
                                        removed_services_file.write('=' * 50 + '\n\n')

                                print("[ServiceScanUpdates] Removed services file updated with %d entries" % removed_count)

                            except Exception as e:
                                print("[ServiceScanUpdates] Error creating removed services file: %s" % str(e))

                except Exception as e:
                    print("[ServiceScanUpdates] Error in post-scan processing: %s" % str(e))
                finally:
                    preScanDB = None
                    scan_in_progress = False
                    print("[ServiceScanUpdates] Scan processing completed")
    except Exception as e:
        print("[ServiceScanUpdates] Error in ServiceScan_execEnd: %s" % str(e))
        scan_in_progress = False

    # Call the original function
    if baseServiceScan_execEnd:
        try:
            # Try to call the function without onClose first
            baseServiceScan_execEnd(self)
        except TypeError:
            # If it fails, try with onClose
            try:
                baseServiceScan_execEnd(self, onClose)
            except Exception as e:
                print("[ServiceScanUpdates] Error calling base execEnd: %s" % str(e))
        except Exception as e:
            print("[ServiceScanUpdates] Error calling base execEnd: %s" % str(e))
    else:
        print("[ServiceScanUpdates] baseServiceScan_execEnd is None")

# --- Autostart hook ---
def autostart(reason, **kwargs):
    # Called on session start / autostart
    if reason == 0 and "session" in kwargs:
        # Initialize settings first
        init_config()

        global baseServiceScan_execBegin, baseServiceScan_execEnd

        # Only proceed if ServiceScan class was found/imported
        if ServiceScan is None:
            print("[ServiceScanUpdates] ServiceScan not available - plugin disabled")
            return
        # Save original methods if not already saved, and wrap them 
        try:
            if baseServiceScan_execBegin is None and hasattr(ServiceScan, "execBegin"):
                baseServiceScan_execBegin = ServiceScan.execBegin
                ServiceScan.execBegin = ServiceScan_execBegin
                print("[ServiceScanUpdates] Successfully patched execBegin")
        except Exception as e:
            print("[ServiceScanUpdates] Error patching execBegin: %s" % str(e))
        try:
            if baseServiceScan_execEnd is None and hasattr(ServiceScan, "execEnd"):
                baseServiceScan_execEnd = ServiceScan.execEnd
                ServiceScan.execEnd = ServiceScan_execEnd
                print("[ServiceScanUpdates] Successfully patched execEnd")
        except Exception as e:
            print("[ServiceScanUpdates] Error patching execEnd: %s" % str(e))

# --- Setup screen opener ---
def open_service_scan_setup(session, **kwargs):
    # Open the setup screen for the plugin
    try:
        from .SSUSetupScreen import SSUSetupScreen
        session.open(SSUSetupScreen)
    except Exception as e:
        # fail silently if screen cannot be opened
        pass

# --- Menu integration ---
def SSUMenuItem(menuid, **kwargs):
    # Plugin appears in Setup ? Service searching
    if menuid == "scan":
        return [(_("Service Scan Setup"), open_service_scan_setup, "servicescanupdates", None)]
    return []

# --- Plugin registration ---
def Plugins(**kwargs):
    # Register plugin descriptors
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
                         fnc=autostart),
        # Plugin appears in Plugin menu
        PluginDescriptor(name=_("Service Scan Setup"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         icon="plugin.png",
                         fnc=open_service_scan_setup),
        # Plugin appears in Setup ? Service searching (scan menu)
        PluginDescriptor(name=_("Service Scan Setup"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_MENU,
                         fnc=SSUMenuItem)
    ]                         