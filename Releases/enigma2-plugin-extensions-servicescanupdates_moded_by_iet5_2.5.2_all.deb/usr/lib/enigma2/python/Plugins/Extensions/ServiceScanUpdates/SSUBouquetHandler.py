# -*- coding: utf-8 -*-
from __future__ import print_function
from enigma import eDVBDB
from Tools.Directories import fileExists, resolveFilename, SCOPE_CONFIG
import time
from datetime import datetime
import os

class SSUBouquetHandler:
    SSU_BOUQUET_PREFIX = "userbouquet.ServiceScanUpdates"

    def __init__(self):
        self.service_scan_timestamp = int(time.time())
        self.ssu_bouquet_filepath_prefix = os.path.join(resolveFilename(SCOPE_CONFIG), self.SSU_BOUQUET_PREFIX)

    def reloadBouquets(self):
        try:
            from enigma import eDVBDB
            eDVBDB.getInstance().reloadBouquets()
        except Exception as e:
            print("[SSUBouquetHandler] Error reloading bouquets:", str(e))

    def doesSSUBouquetFileExists(self, bouquet_type):
        filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
        return fileExists(filename)

    def addToIndexBouquet(self, bouquet_type):
        try:
            import sys
            PY2 = sys.version_info[0] == 2
            PY3 = sys.version_info[0] == 3
            
            index_file = os.path.join(resolveFilename(SCOPE_CONFIG), "bouquets.%s" % bouquet_type)
            bouquet_line = '#SERVICE 1:7:%d:0:0:0:0:0:0:0:FROM BOUQUET "%s.%s" ORDER BY bouquet\n' % (
                1 if bouquet_type == "tv" else 2, self.SSU_BOUQUET_PREFIX, bouquet_type)
            
            # enigma2 uses latin-1 encoding for bouquet files
            if PY2:
                if not os.path.exists(index_file):
                    with open(index_file, "w") as f:
                        f.write("#NAME Bouquets (%s)\n" % bouquet_type)
                
                with open(index_file, "r") as f:
                    content = f.read()
                
                if bouquet_line not in content:
                    with open(index_file, "a") as f:
                        f.write(bouquet_line)
            else:
                # Python 3: use latin-1 as enigma2 standard
                if not os.path.exists(index_file):
                    with open(index_file, "w", encoding='latin-1') as f:
                        f.write("#NAME Bouquets (%s)\n" % bouquet_type)
                
                with open(index_file, "r", encoding='latin-1') as f:
                    content = f.read()
                
                if bouquet_line not in content:
                    with open(index_file, "a", encoding='latin-1') as f:
                        f.write(bouquet_line)
                    
        except Exception as e:
            print("[SSUBouquetHandler] Error adding to index:", str(e))

    def createSSUBouquet(self, services, bouquet_type):
        try:
            import sys
            PY2 = sys.version_info[0] == 2
            PY3 = sys.version_info[0] == 3
            
            content = ["#NAME Service Scan Updates\n"]
            
            from datetime import datetime
            datetime_string = datetime.fromtimestamp(self.service_scan_timestamp).strftime("%d.%m.%Y - %H:%M")
            content.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
            content.append("#DESCRIPTION ------- %s -------\n" % datetime_string)
            
            total_services = 0
            for orbital_pos, service_list in services.items():
                content.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
                content.append("#DESCRIPTION ------- %s -------\n" % orbital_pos)
                
                for service in service_list:
                    content.append("#SERVICE %s\n" % service)
                    total_services += 1
            
            filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
            print("[SSUBouquetHandler] Creating bouquet file: %s with %d services" % (filename, total_services))
            
            # enigma2 uses latin-1 encoding for bouquet files
            if PY2:
                with open(filename, "w") as f:
                    f.writelines(content)
            else:
                with open(filename, "w", encoding='latin-1') as f:
                    f.writelines(content)
            
            print("[SSUBouquetHandler] Bouquet file created successfully: %s" % filename)
                
        except Exception as e:
            print("[SSUBouquetHandler] Error creating bouquet:", str(e))
            import traceback
            traceback.print_exc()

    def appendToSSUBouquet(self, services, bouquet_type):
        try:
            import sys
            PY2 = sys.version_info[0] == 2
            PY3 = sys.version_info[0] == 3
            
            filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
            
            # enigma2 uses latin-1 encoding for bouquet files
            if PY2:
                with open(filename, "r") as f:
                    old_content = f.readlines()
            else:
                with open(filename, "r", encoding='latin-1') as f:
                    old_content = f.readlines()
            
            new_content = []
            from datetime import datetime
            datetime_string = datetime.fromtimestamp(self.service_scan_timestamp).strftime("%d.%m.%Y - %H:%M")
            
            new_content.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
            new_content.append("#DESCRIPTION ------- %s -------\n" % datetime_string)
            
            for orbital_pos, service_list in services.items():
                new_content.append("#SERVICE 1:64:0:0:0:0:0:0:0:0:\n")
                new_content.append("#DESCRIPTION ------- %s -------\n" % orbital_pos)
                
                for service in service_list:
                    new_content.append("#SERVICE %s\n" % service)
            
            # Insert new content after name line
            final_content = []
            for line in old_content:
                final_content.append(line)
                if line.strip() == "#NAME Service Scan Updates":
                    final_content.extend(new_content)
            
            if PY2:
                with open(filename, "w") as f:
                    f.writelines(final_content)
            else:
                with open(filename, "w", encoding='latin-1') as f:
                    f.writelines(final_content)
                
        except Exception as e:
            print("[SSUBouquetHandler] Error appending to bouquet:", str(e))