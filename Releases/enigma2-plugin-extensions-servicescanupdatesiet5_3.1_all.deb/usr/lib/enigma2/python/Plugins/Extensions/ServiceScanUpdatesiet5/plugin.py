# -*- coding: utf-8 -*-
# Developer   : MacDisein
# Modified by : iet5

from __future__ import print_function

import os
import time
import traceback
from datetime import datetime
from collections import defaultdict

from Plugins.Plugin import PluginDescriptor
from Components.config import config
from Tools.Directories import resolveFilename, SCOPE_CONFIG
from Screens.MessageBox import MessageBox

# Hook the screen lifetime: legacy images keep their scan engine in a component,
# while recent OpenATV versions implement it directly in this screen.
try:
    from Screens.ServiceScan import ServiceScan
except ImportError:
    ServiceScan = None

from . import _, getRuntimeProfile, initConfig, readTextFile, atomicWriteText, toText, logMessage, logException, initializeLog
from .SSULameDBParser import SSULameDBParser
from .SSUBouquetHandler import SSUBouquetHandler

PLUGIN_RUNTIME_PROFILE = getRuntimeProfile()

def init_config():
    return initConfig()


def dictHasKey(dictionary, key):
    return key in dictionary


# Resolve the best path for the removed services report
def getRemovedServicesFilePath():
    preferred_dirs = (
        "/media/hdd",
        "/media/usb",
        "/media/mmc",
        resolveFilename(SCOPE_CONFIG),
    )
    for directory in preferred_dirs:
        if directory and os.path.isdir(directory) and os.access(directory, os.W_OK):
            return os.path.join(directory, "removed_services.txt")
    return os.path.join(resolveFilename(SCOPE_CONFIG), "removed_services.txt")


def writeReportLines(path, mode, lines):
    text = "".join(toText(line) for line in lines) if isinstance(lines, list) else toText(lines)
    if mode == "a" and os.path.exists(path):
        text = readTextFile(path, strict=True) + text
    atomicWriteText(path, text)


# Create or update the removed services report
def updateRemovedServicesFile(preScanServices, postScanServices):
    logMessage("[ServiceScanUpdates] REMOVED report requested; before=%d after=%d" % (len(preScanServices), len(postScanServices)))
    settings = config.plugins.servicescanupdates
    if not settings.create_removed_services_file.value:
        logMessage("[ServiceScanUpdates] REMOVED report disabled; skipped")
        return

    try:
        datetime_string = datetime.fromtimestamp(time.time()).strftime("%d.%m.%Y - %H:%M")
        removed_file_path = getRemovedServicesFilePath()

        removed_services = defaultdict(list)
        removed_count = 0

        # Search for removed services
        for service_ref in preScanServices.keys():
            if not dictHasKey(postScanServices, service_ref):
                removed_service = preScanServices[service_ref]
                service_name = removed_service.get("service_name", "Unknown Service")
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                entry = "%s (%s)" % (str(service_ref), service_name)
                removed_services[orbital_pos].append(entry)
                removed_count += 1
                logMessage("[ServiceScanUpdates] Removed service: %s" % service_ref)

        # Write new removed services
        payload = []
        payload.append("=== Scan at: %s ===\n" % datetime_string)
        payload.append("Total removed services: %d\n" % removed_count)

        if removed_count > 0:
            orbital_positions = list(removed_services.keys())
            orbital_positions.sort()
            for orbital_pos in orbital_positions:
                payload.append("\n--- %s ---\n" % orbital_pos)
                for entry in removed_services[orbital_pos]:
                    payload.append("%s\n" % entry)
        else:
            payload.append("No services were removed in this scan.\n")

        payload.append("=" * 50 + "\n\n")
        writeReportLines(removed_file_path, "a", payload)
        logMessage("[ServiceScanUpdates] Removed services file updated with %d entries at %s" % (removed_count, removed_file_path))

    except Exception as e:
        logMessage("[ServiceScanUpdates] Error creating removed services file: %s" % str(e))
        logException()


# Build dictionaries of new TV and radio services
def collectNewServices(preScanServices, postScanServices):
    logMessage("[ServiceScanUpdates] COMPARE begin; before=%d after=%d" % (len(preScanServices), len(postScanServices)))
    newTVServices = defaultdict(list)
    newRadioServices = defaultdict(list)
    new_services_found = 0

    # Detect new services
    for service_ref in postScanServices.keys():
        if dictHasKey(preScanServices, service_ref):
            continue

        new_services_found += 1
        try:
            if SSULameDBParser.isVideoService(service_ref):
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                newTVServices[orbital_pos].append(service_ref)
                logMessage("[ServiceScanUpdates] New TV service: %s" % service_ref)
            elif SSULameDBParser.isRadioService(service_ref):
                orbital_pos = SSULameDBParser.getOrbitalPos(service_ref)
                newRadioServices[orbital_pos].append(service_ref)
                logMessage("[ServiceScanUpdates] New Radio service: %s" % service_ref)
        except Exception as e:
            logMessage("[ServiceScanUpdates] Error processing service %s: %s" % (service_ref, str(e)))

    logMessage("[ServiceScanUpdates] Total new services found: %d" % new_services_found)
    return newTVServices, newRadioServices


# Process TV and radio bouquet updates
def updateBouquets(newTVServices, newRadioServices):
    logMessage("[ServiceScanUpdates] BOUQUETS begin; tv=%d radio=%d" % (
        sum(len(v) for v in newTVServices.values()), sum(len(v) for v in newRadioServices.values())))
    bouquet_handler = SSUBouquetHandler()
    settings = config.plugins.servicescanupdates
    logMessage("[ServiceScanUpdates] BOUQUETS options tv=%s radio=%s clear=%s always=%s" % (
        settings.add_new_tv_services.value, settings.add_new_radio_services.value,
        settings.clear_bouquet.value, settings.always_create_bouquet.value))

    # Process TV services
    tv_count = sum(len(services) for services in newTVServices.values())
    if settings.add_new_tv_services.value and (tv_count > 0 or settings.always_create_bouquet.value or settings.clear_bouquet.value):
        try:
            if settings.clear_bouquet.value:
                bouquet_handler.createSSUBouquet(newTVServices, "tv")
            elif bouquet_handler.doesSSUBouquetFileExists("tv"):
                bouquet_handler.appendToSSUBouquet(newTVServices, "tv")
            else:
                bouquet_handler.createSSUBouquet(newTVServices, "tv")
            bouquet_handler.addToIndexBouquet("tv")
            logMessage("[ServiceScanUpdates] TV bouquet processed successfully")
        except Exception as e:
            logMessage("[ServiceScanUpdates] Error creating TV bouquet: %s" % str(e))
            logException()

    # Process Radio services
    radio_count = sum(len(services) for services in newRadioServices.values())
    if settings.add_new_radio_services.value and (radio_count > 0 or settings.always_create_bouquet.value or settings.clear_bouquet.value):
        try:
            if settings.clear_bouquet.value:
                bouquet_handler.createSSUBouquet(newRadioServices, "radio")
            elif bouquet_handler.doesSSUBouquetFileExists("radio"):
                bouquet_handler.appendToSSUBouquet(newRadioServices, "radio")
            else:
                bouquet_handler.createSSUBouquet(newRadioServices, "radio")
            bouquet_handler.addToIndexBouquet("radio")
            logMessage("[ServiceScanUpdates] Radio bouquet processed successfully")
        except Exception as e:
            logMessage("[ServiceScanUpdates] Error creating Radio bouquet: %s" % str(e))
            logException()

    # Reload bouquets
    try:
        bouquet_handler.reloadBouquets()
        logMessage("[ServiceScanUpdates] Bouquets reloaded successfully")
    except Exception as e:
        logMessage("[ServiceScanUpdates] Error reloading bouquets: %s" % str(e))
        logException()


def loadServiceDatabase():
    logMessage("[ServiceScanUpdates] DATABASE snapshot begin")
    from enigma import eDVBDB
    database = eDVBDB.getInstance()
    # Scans update the in-memory DB; flush it before comparing disk snapshots.
    if hasattr(database, "saveServicelist"):
        logMessage("[ServiceScanUpdates] DATABASE flushing in-memory services to disk")
        database.saveServicelist()
    directory = resolveFilename(SCOPE_CONFIG)
    for filename in ("lamedb", "lamedb5"):
        path = os.path.join(directory, filename)
        logMessage("[ServiceScanUpdates] DATABASE candidate=%s exists=%s" % (path, os.path.exists(path)))
        if os.path.exists(path):
            parsed = SSULameDBParser(path)
            if parsed.valid:
                logMessage("[ServiceScanUpdates] DATABASE snapshot ready; path=%s services=%d" % (path, len(parsed.getServices())))
                return parsed
    raise ValueError("No complete, supported service database found")


def scanCompleted(screen):
    controller = screen
    try:
        controller = screen["scan"]
    except (KeyError, TypeError, AttributeError):
        pass
    # Legacy DreamOS/OpenPLi components use Done; modern OpenATV uses DONE.
    for name in ("Done", "DONE"):
        done = getattr(controller, name, None)
        if done is not None:
            return getattr(controller, "state", None) == done
    return False


def processScan(screen):
    logMessage("[ServiceScanUpdates] SCAN closing; processing results")
    before = getattr(screen, "_ssu_before", None)
    screen._ssu_before = None
    if before is None or not getattr(screen, "_ssu_completed", scanCompleted(screen)):
        logMessage("[ServiceScanUpdates] SCAN skipped; snapshot=%s completed=%s" % (
            before is not None, getattr(screen, "_ssu_completed", False)))
        return
    try:
        after = loadServiceDatabase()
        new_tv, new_radio = collectNewServices(before.getServices(), after.getServices())
        updateBouquets(new_tv, new_radio)
        updateRemovedServicesFile(before.getServices(), after.getServices())
        logMessage("[ServiceScanUpdates] SCAN processing finished; see operation results above")
    except Exception:
        logMessage("[ServiceScanUpdates] Failed to process scan results")
        logException()


def autostart(reason, **kwargs):
    if reason == 0:
        initializeLog()
    logMessage("[ServiceScanUpdates] AUTOSTART reason=%s session=%s scan_screen_available=%s" % (
        reason, "session" in kwargs, ServiceScan is not None))
    if reason != 0 or "session" not in kwargs or ServiceScan is None:
        return
    init_config()
    original = ServiceScan.__init__
    if getattr(original, "_ssu_hook", False):
        logMessage("[ServiceScanUpdates] HOOK already installed; skipped")
        return

    original_end = ServiceScan.execEnd

    def scanEnd(screen, *args, **kw):
        # Legacy component execEnd may set Done even on cancellation. Capture
        # the real state before cleanup, forwarding each image signature once.
        screen._ssu_completed = scanCompleted(screen)
        logMessage("[ServiceScanUpdates] SCAN execEnd completed=%s" % screen._ssu_completed)
        return original_end(screen, *args, **kw)

    def scanInit(screen, *args, **kw):
        logMessage("[ServiceScanUpdates] SCAN starting; capturing before snapshot")
        before = None
        settings = init_config()
        if (settings.add_new_tv_services.value or settings.add_new_radio_services.value
                or settings.create_removed_services_file.value):
            try:
                before = loadServiceDatabase()
            except Exception:
                logException()
        original(screen, *args, **kw)
        logMessage("[ServiceScanUpdates] SCAN native screen initialized; snapshot=%s" % (before is not None))
        screen._ssu_before = before
        # onClose runs once, after all scan passes, without changing execEnd's
        # signature or treating a temporary screen suspension as a finished scan.
        screen.onClose.insert(0, lambda: processScan(screen))

    scanInit._ssu_hook = True
    ServiceScan.__init__ = scanInit
    ServiceScan.execEnd = scanEnd
    logMessage("[ServiceScanUpdates] Scan hook installed: %s" % PLUGIN_RUNTIME_PROFILE)


# --- Setup screen opener ---
def open_service_scan_setup(session, **kwargs):
    logMessage("[ServiceScanUpdates] SETUP open requested")
    # An import failure happens before the session starts a screen transition.
    try:
        from .SSUSetupScreen import SSUSetupScreen
    except Exception as e:
        logMessage("[ServiceScanUpdates] Failed to import setup screen: %s" % str(e))
        logException()
        try:
            session.open(
                MessageBox,
                _("Unable to open the Service Scan Updates setup screen. Please check the log for details."),
                MessageBox.TYPE_ERROR
            )
        except Exception:
            pass
        return

    try:
        return session.open(SSUSetupScreen)
    except Exception:
        # session.open may already have suspended the browser or changed the
        # dialog stack. Opening another dialog here can hide the first error
        # and leave DreamOS processing the wrong current_dialog on close.
        details = traceback.format_exc()
        logMessage("[ServiceScanUpdates] Failed to open setup screen:\n%s" % details)
        # Let Enigma2 report the original failure instead of swallowing it.
        raise


# --- Menu integration ---
def SSUMenuItem(menuid, **kwargs):
    # Plugin appears in Setup -> Service searching
    if menuid == "scan":
        return [(_("Service Scan Updates"), open_service_scan_setup, "servicescanupdates", None)]
    return []


# --- Plugin registration ---
def Plugins(**kwargs):
    # Register plugin descriptors
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART],
                         fnc=autostart),
        # Plugin appears in Plugin menu
        PluginDescriptor(name=_("Service Scan Updates"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         icon="plugin.png",
                         fnc=open_service_scan_setup),
        # Plugin appears in Setup -> Service searching (scan menu)
        PluginDescriptor(name=_("Service Scan Updates"),
                         description=_("Service scan setup and new services handling"),
                         where=PluginDescriptor.WHERE_MENU,
                         fnc=SSUMenuItem)
    ]
