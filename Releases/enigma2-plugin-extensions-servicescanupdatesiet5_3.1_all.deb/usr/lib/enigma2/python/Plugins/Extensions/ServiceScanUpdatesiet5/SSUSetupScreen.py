# -*- coding: utf-8 -*-
from __future__ import print_function, division

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.config import configfile, ConfigYesNo
from Components.Label import Label
from enigma import getDesktop
from . import (
    _,
    getRuntimeProfile,
    initConfig,
    pluginResourcePath,
    readTextFile,
    toNativeText,
    logMessage,
    LOG_FILE_PATH,
)

# ===== Global Variables =====
PLUGIN_RUNTIME_PROFILE = getRuntimeProfile()
# ===== Initialize settings once and reuse them =====
PLUGIN_SETTINGS = initConfig()

# ===== Version =====
def read_version():
    version_text = readTextFile(pluginResourcePath("version.txt"), "").strip()
    if version_text:
        return toNativeText(version_text)
    return "Unknown version"

version = read_version()

def buildStyledSkin(desktop_width, desktop_height, log_options=False, wide_rows=False):
    # Match the supplied settings reference. The side rails are exactly 15 px.
    width = min(1280, int(desktop_width * 0.95))
    height = min(1000, int(desktop_height * 0.92))
    scale = min(width / 1280.0, height / 1000.0)
    def n(value):
        return max(1, int(value * scale))
    rail = 15
    left = rail + n(14)
    inner = width - 2 * left
    header_h = n(62)
    meta_y = header_h + n(8)
    meta_h = n(55)
    group_y = meta_y + meta_h + n(14)
    group_h = n(44)
    config_y = group_y + group_h + n(12)
    buttons_y = height - n(110)
    help_y = buttons_y - n(130)
    config_h = help_y - config_y - n(15)
    name = "SSULogOptionsScreen" if log_options else "SSUSetupScreen"
    xml = ['<screen name="%s" position="center,center" size="%d,%d" title="Service Scan Updates" flags="wfNoBorder" backgroundColor="#003b3b3b">' % (name, width, height)]
    def block(x, y, w, h, color):
        xml.append('<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s" zPosition="0" />' % (x, y, w, h, color))
    def label(name, x, y, w, h, font, color="#00ffffff", align="left"):
        xml.append('<widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" transparent="1" valign="center" halign="%s" zPosition="2" />' % (name, x, y, w, h, font, color, align))
    # Gray title strip, red credit/version, gold rules and a black body.
    block(0, 0, width, header_h, "#006b7075")
    label("title_left", left, 0, inner, header_h, n(34), "#0033ff00")
    label("modified", left, meta_y, inner - n(170), meta_h, n(30), "#00ff1515")
    label("title_right", width - left - n(170), meta_y, n(170), meta_h, n(30), "#00ff1515", "right")
    body_y = group_y - n(8)
    block(rail, body_y, width - 2 * rail, buttons_y - body_y, "#00000000")
    block(rail, 0, 1, height, "#00505050")
    block(width - rail, 0, 1, height, "#00505050")
    block(rail, body_y, width - 2 * rail, n(2), "#00c78f28")
    label("group_title", left, group_y, inner, group_h, n(30), "#00e8ad36")
    block(left, group_y + group_h, inner, n(1), "#00c78f28")
    # Keep native ON/OFF rendering; DreamOS config widgets reject font=.
    # OpenATV 8.1's larger default list font needs a taller row, or the five
    # option lines render squeezed together; other images keep the compact row.
    item_height = n(58) if wide_rows else n(40)
    xml.append('<widget name="config" position="%d,%d" size="%d,%d" itemHeight="%d" scrollbarMode="showOnDemand" backgroundColor="#00000000" foregroundColor="#00ffffff" zPosition="1" />' % (left, config_y, inner, config_h, item_height))
    label("help", left + n(12), help_y, inner - n(24), n(90), n(27))
    label("footer", left, help_y + n(92), inner, n(28), n(21),
          "#00bdbdbd" if log_options else "#00ffd700", "center")
    block(rail, buttons_y, width - 2 * rail, n(2), "#00c78f28")
    buttons = (("key_red", "#00ef233c"), ("key_green", "#002bb673"))
    if not log_options:
        buttons += (("key_yellow", "#00e2c331"), ("key_options", "#002cb6df"))
    slot = inner // len(buttons)
    for index, (name, color) in enumerate(buttons):
        x = left + index * slot
        label(name, x, buttons_y + n(12), slot, n(47), n(29), align="center")
        line_w = min(n(165), slot - n(36))
        block(x + (slot - line_w) // 2, buttons_y + n(70), line_w, n(3), color)
    xml.append('</screen>')
    return "\n".join(xml)


def buildSkin(desktop_width, desktop_height, wide_rows=False):
    return buildStyledSkin(desktop_width, desktop_height, wide_rows=wide_rows)


def buildLogOptionsSkin(desktop_width, desktop_height):
    return buildStyledSkin(desktop_width, desktop_height, log_options=True)


class SSULogOptionsScreen(ConfigListScreen, Screen):
    def __init__(self, session):
        size = getDesktop(0).size()
        self.skin = buildLogOptionsSkin(size.width(), size.height())
        Screen.__init__(self, session)
        self["title_left"] = Label("Service Scan Updates - Log file options")
        self["modified"] = Label("Modified by iet5")
        self["title_right"] = Label("Ver. %s" % version)
        self["group_title"] = Label("Diagnostics")
        self["footer"] = Label("The previous log is cleared when Enigma2 restarts.")
        # Edit a temporary value; Cancel must not change active logging.
        self.log_enabled = ConfigYesNo(default=PLUGIN_SETTINGS.enable_log.value)
        self["help"] = Label("Use LEFT / RIGHT to turn log file writing ON or OFF.")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        ConfigListScreen.__init__(self, [
            ("Enable log file writing", self.log_enabled)
        ], session=session)
        self["logActions"] = ActionMap(
            ["SetupActions", "ColorActions"], {
                "red": self.keyCancel, "cancel": self.keyCancel,
                "green": self.keySave, "save": self.keySave,
                "ok": self.keySave,
            }, -2)

    def keySave(self):
        self.close(bool(self.log_enabled.value))

    def keyCancel(self):
        self.close(None)


class SSUSetupScreen(ConfigListScreen, Screen):
    def __init__(self, session):
        self.session = session

        # ===== Choose Skin based on resolution =====
        desktop_size = getDesktop(0).size()
        screen_width = desktop_size.width()
        screen_height = desktop_size.height()
        logMessage("[ServiceScanUpdates] Screen size: {}x{}".format(screen_width, screen_height))
        logMessage("[ServiceScanUpdates] Runtime profile: %s" % str(PLUGIN_RUNTIME_PROFILE))

        self.skin = buildSkin(screen_width, screen_height,
                              wide_rows=PLUGIN_RUNTIME_PROFILE.get("openatv", False))

        Screen.__init__(self, session)

        # ===== Widgets =====
        self["title_left"] = Label("Service Scan Updates - Settings")
        self["modified"] = Label("Modified by iet5")
        self["title_right"] = Label("Ver. %s" % version)
        self["group_title"] = Label("Scan update options")
        self["help"] = Label(_("Configure the update options."))
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save"))
        # "key_menu" is a reserved widget name on some images (it stays blank
        # regardless of the text set on it); use a plain, unreserved name instead.
        self["key_options"] = Label(_("Options"))
        self["key_yellow"] = Label("Help")
        self["footer"] = Label(_("Developer MacDisein - modified for Python 2 and Python 3 compatibility by iet5"))

        # Supply the complete list before native widgets are created. Replacing
        # it from onLayoutFinish resets selection while the GUI is being built.
        self.list = self.getSettingsList()
        ConfigListScreen.__init__(self, self.list, session=session, on_change=self._settingChanged)

        # ===== ActionMap =====
        self["setupActions"] = ActionMap(
            ["SetupActions", "ColorActions", "HelpActions", "InfobarEPGActions", "MenuActions"],
            {
                "red": self.keyCancel,
                "green": self.keySave,
                "cancel": self.keyCancel,
                "save": self.keySave,
                "ok": self.keySave,
                "displayHelp": self.showHelp,
                "info": self.showHelp,
                "menu": self.showOptions,
                "blue": self.showOptions,
                "yellow": self.showHelp,
            },
            -2
        )

        # Config list setup
        self.onLayoutFinish.append(self._layoutReady)
        if hasattr(self["config"], "onSelectionChanged"):
            self["config"].onSelectionChanged.append(self.updateHelp)
        self.onClose.append(self._setupClosed)
        logMessage("[ServiceScanUpdates] SETUP initialized; file logging=%s" % PLUGIN_SETTINGS.enable_log.value)

    # ===== Other Methods =====
    def _layoutReady(self):
        self.updateHelp()
        logMessage("[ServiceScanUpdates] Setup layout ready")

    def _setupClosed(self):
        logMessage("[ServiceScanUpdates] SETUP closed")

    def _settingChanged(self):
        current = self["config"].getCurrent()
        if current:
            logMessage("[ServiceScanUpdates] CONFIG changed %s=%s" % (current[0], current[1].value))

    def showOptions(self):
        enabled = PLUGIN_SETTINGS.enable_log.value
        logMessage("[ServiceScanUpdates] MENU opened; logging=%s" % enabled)
        self.session.openWithCallback(
            self.logOptionSelected, SSULogOptionsScreen)

    def logOptionSelected(self, choice):
        if choice is None:
            logMessage("[ServiceScanUpdates] MENU cancelled")
            return
        enabled = bool(choice)
        if not enabled:
            logMessage("[ServiceScanUpdates] LOG disabled by user")
        PLUGIN_SETTINGS.enable_log.value = enabled
        PLUGIN_SETTINGS.enable_log.save()
        configfile.save()
        if enabled:
            logMessage("[ServiceScanUpdates] LOG enabled; file=%s; version=%s; profile=%s" % (
                LOG_FILE_PATH, version, PLUGIN_RUNTIME_PROFILE))
            for name in ("add_new_tv_services", "add_new_radio_services", "always_create_bouquet",
                         "create_removed_services_file", "clear_bouquet"):
                logMessage("[ServiceScanUpdates] CONFIG %s=%s" % (name, getattr(PLUGIN_SETTINGS, name).value))

    def getSettingsList(self):
        return [
            (_("Add new TV services"), PLUGIN_SETTINGS.add_new_tv_services, _("Create the 'Service Scan Updates' bouquet for new TV services.")),
            (_("Add new radio services"), PLUGIN_SETTINGS.add_new_radio_services, _("Create the 'Service Scan Updates' bouquet for new radio services.")),
            (_("Always create bouquet"), PLUGIN_SETTINGS.always_create_bouquet, _("Always create the 'Service Scan Updates' bouquet, even if no new services were found.")),
            (_("Create removed services file"), PLUGIN_SETTINGS.create_removed_services_file, _("Save removed channels on writable HDD, USB, MMC or in the receiver settings folder.")),
            (_("Clear bouquet at each search"), PLUGIN_SETTINGS.clear_bouquet, _("Clear the 'Service Scan Updates' bouquet on every scan instead of appending new services.")),
        ]

    def updateHelp(self):
        cur = self["config"].getCurrent()
        if cur and len(cur) > 2:
            self["help"].setText(cur[2])
            logMessage("[ServiceScanUpdates] SETUP selection=%s value=%s" % (cur[0], cur[1].value))
        else:
            self["help"].setText(_("Configure the update options."))

    def showHelp(self):
        logMessage("[ServiceScanUpdates] HELP opened")
        help_lines = [
            _("This plugin creates a favourites bouquet for TV and Radio named 'Service Scan Updates'."),
            _("All new services found during the scan are inserted there together with a separator."),
            _("This helps you quickly review the services found during the latest search."),
            _("You can then move individual services to your own favourites bouquets as usual."),
            "",
            _("To display the 'Service Scan Updates' bouquet, enable the 'Allow multiple bouquets' option in the receiver settings."),
        ]
        help_txt = "\n".join(help_lines)
        self.session.open(MessageBox, help_txt, MessageBox.TYPE_INFO)

    def keySave(self):
        logMessage("[ServiceScanUpdates] SETUP saving options")
        for x in self["config"].list:
            logMessage("[ServiceScanUpdates] CONFIG save %s=%s" % (x[0], x[1].value))
            x[1].save()
        configfile.save()
        self.close()

    def keyCancel(self):
        logMessage("[ServiceScanUpdates] SETUP cancelling unsaved options")
        for x in self["config"].list:
            x[1].cancel()
        self.close()

