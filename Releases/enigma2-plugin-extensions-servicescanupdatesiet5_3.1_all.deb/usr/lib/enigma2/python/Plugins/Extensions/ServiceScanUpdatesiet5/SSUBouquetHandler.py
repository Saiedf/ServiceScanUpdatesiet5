# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import time
from datetime import datetime
from Tools.Directories import resolveFilename, SCOPE_CONFIG
from . import readTextFile, atomicWriteText, toText, logMessage


class SSUBouquetHandler(object):
    SSU_BOUQUET_PREFIX = "userbouquet.ServiceScanUpdates"

    def __init__(self):
        self.service_scan_timestamp = int(time.time())
        self.ssu_bouquet_filepath_prefix = os.path.join(resolveFilename(SCOPE_CONFIG), self.SSU_BOUQUET_PREFIX)
        logMessage("[ServiceScanUpdates] BOUQUET handler ready: %s" % self.ssu_bouquet_filepath_prefix)

    def reloadBouquets(self):
        logMessage("[ServiceScanUpdates] BOUQUET requesting native reload")
        from enigma import eDVBDB
        # Reloading the service DB from disk here could discard unrelated updates.
        eDVBDB.getInstance().reloadBouquets()

    def doesSSUBouquetFileExists(self, bouquet_type):
        return os.path.isfile("%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type))

    def _readBouquetLines(self, filename):
        logMessage("[ServiceScanUpdates] BOUQUET reading %s" % filename)
        return readTextFile(filename, strict=True).splitlines(True)

    def _writeBouquetLines(self, filename, lines):
        logMessage("[ServiceScanUpdates] BOUQUET writing %d lines to %s" % (len(lines), filename))
        atomicWriteText(filename, "".join(toText(line) for line in lines))

    def _buildBouquetSection(self, services):
        if not any(services.values()):
            return []
        stamp = datetime.fromtimestamp(self.service_scan_timestamp).strftime("%d.%m.%Y - %H:%M")
        marker = "#SERVICE 1:64:0:0:0:0:0:0:0:0:\n"
        lines = [marker, "#DESCRIPTION ------- %s -------\n" % stamp]
        seen = set()
        for orbital_pos in sorted(services):
            refs = []
            for ref in services[orbital_pos]:
                if ref not in seen:
                    refs.append(ref)
                    seen.add(ref)
            if refs:
                lines.extend([marker, "#DESCRIPTION ------- %s -------\n" % orbital_pos])
                lines.extend("#SERVICE %s\n" % ref for ref in refs)
        return lines

    def addToIndexBouquet(self, bouquet_type):
        logMessage("[ServiceScanUpdates] BOUQUET index update begin: %s" % bouquet_type)
        index_file = os.path.join(resolveFilename(SCOPE_CONFIG), "bouquets.%s" % bouquet_type)
        name = "%s.%s" % (self.SSU_BOUQUET_PREFIX, bouquet_type)
        content = (readTextFile(index_file, strict=True) if os.path.exists(index_file)
                   else "#NAME Bouquets (%s)\n" % bouquet_type)
        if any('FROM BOUQUET "%s"' % name in line for line in content.splitlines()):
            logMessage("[ServiceScanUpdates] BOUQUET already indexed: %s" % name)
            return
        if content and not content.endswith("\n"):
            content += "\n"
        content += '#SERVICE 1:7:%d:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % (
            1 if bouquet_type == "tv" else 2, name)
        atomicWriteText(index_file, content)

    def createSSUBouquet(self, services, bouquet_type):
        logMessage("[ServiceScanUpdates] BOUQUET create/replace: %s" % bouquet_type)
        filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
        self._writeBouquetLines(filename, ["#NAME Service Scan Updates\n"] + self._buildBouquetSection(services))

    def appendToSSUBouquet(self, services, bouquet_type):
        logMessage("[ServiceScanUpdates] BOUQUET append begin: %s" % bouquet_type)
        if not self.doesSSUBouquetFileExists(bouquet_type):
            self.createSSUBouquet(services, bouquet_type)
            return
        filename = "%s.%s" % (self.ssu_bouquet_filepath_prefix, bouquet_type)
        old = self._readBouquetLines(filename)
        existing = set(line[len("#SERVICE "):].strip() for line in old if line.startswith("#SERVICE "))
        fresh = dict((pos, [ref for ref in refs if ref not in existing]) for pos, refs in services.items())
        new = self._buildBouquetSection(fresh)
        if not new:
            logMessage("[ServiceScanUpdates] BOUQUET no nonduplicate services to append")
            return
        if old and old[0].startswith("#NAME "):
            if not old[0].endswith("\n"):
                old[0] += "\n"
            content = old[:1] + new + old[1:]
        else:
            content = ["#NAME Service Scan Updates\n"] + new + old
        self._writeBouquetLines(filename, content)
