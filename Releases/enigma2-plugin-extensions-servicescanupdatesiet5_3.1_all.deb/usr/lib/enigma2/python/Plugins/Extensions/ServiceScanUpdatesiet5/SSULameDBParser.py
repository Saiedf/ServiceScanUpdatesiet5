# -*- coding: utf-8 -*-
from __future__ import print_function

import re
from enigma import eDVBDB, eServiceReference
from . import _, readTextFile, logMessage

FLAG_SERVICE_NEW_FOUND = 64


class SSULameDBParser(object):
    def __init__(self, filename):
        logMessage("[ServiceScanUpdates] PARSER opening %s" % filename)
        self.filename = filename
        self.version = None
        self.valid = False
        self.services = {}
        self.transponders = {}
        self.parse(self.load())

    @staticmethod
    def _stripLeadingZeros(value):
        return (value or "").lstrip("0") or "0"

    def load(self):
        lines = readTextFile(self.filename, strict=True).splitlines()
        logMessage("[ServiceScanUpdates] PARSER read %d lines from %s" % (len(lines), self.filename))
        return lines

    def _addService(self, header, name, provider):
        fields = header.split(":")
        if len(fields) not in (6, 7):
            raise ValueError("Invalid service header: %s" % header)
        sid, namespace, tsid, onid = [int(v, 16) for v in fields[:4]]
        kind = int(fields[4])
        ref = "1:0:%X:%X:%X:%X:%X:0:0:0:" % (kind, sid, tsid, onid, namespace)
        data = {
            "service_id": "%x" % sid, "dvb_namespace": "%x" % namespace,
            "transport_stream_id": "%x" % tsid, "original_network_id": "%x" % onid,
            "service_type": "%x" % kind, "service_number": fields[5],
            "transponder": "%08x:%04x:%04x" % (namespace, tsid, onid),
            "service_name": name, "provider": "", "provider_data": [],
        }
        for token in provider.split(","):
            key, separator, value = token.partition(":")
            if separator:
                if key == "p":
                    data["provider"] = value
                else:
                    data["provider_data"].append({key: self._stripLeadingZeros(value)})
        # Older databases allow a plain provider name without p:.
        if provider and ":" not in provider:
            data["provider"] = provider
        self.services[ref] = data
        logMessage("[ServiceScanUpdates] PARSER service=%s name=%s" % (ref, name))

    def parse(self, lines):
        self.valid = False
        self.services = {}
        self.transponders = {}
        if not lines:
            logMessage("[ServiceScanUpdates] PARSER empty database")
            return
        match = re.match(r"^eDVB services /([345])/", lines[0])
        if not match:
            logMessage("[ServiceScanUpdates] PARSER unsupported database header: %s" % lines[0])
            return
        self.version = int(match.group(1))
        logMessage("[ServiceScanUpdates] PARSER format version=%s" % self.version)
        try:
            if self.version == 5:
                for line in lines[1:]:
                    if line.startswith("t:"):
                        header, sep, value = line[2:].partition(",")
                        if not sep:
                            raise ValueError("Invalid transponder")
                        self.transponders[header] = value
                    elif line.startswith("s:"):
                        header, sep, value = line[2:].partition(",")
                        end = value.rfind('"')
                        if not sep or not value.startswith('"') or end < 1:
                            raise ValueError("Invalid v5 service")
                        self._addService(header, value[1:end], value[end + 1:].lstrip(","))
            else:
                start = lines.index("transponders") + 1
                end = lines.index("end", start)
                pending = []
                for line in lines[start:end]:
                    if line == "/":
                        if len(pending) < 2:
                            raise ValueError("Incomplete transponder")
                        self.transponders[pending[0]] = pending[1].strip().replace(" ", ":")
                        pending = []
                    elif line:
                        pending.append(line)
                if pending:
                    raise ValueError("Unterminated transponder")
                start = lines.index("services", end) + 1
                offset = start
                while offset < len(lines) and lines[offset] != "end":
                    entry = lines[offset:offset + 3]
                    if len(entry) != 3:
                        raise ValueError("Incomplete service record")
                    self._addService(*entry)
                    offset += 3
                if offset >= len(lines):
                    raise ValueError("Unterminated service section")
            self.valid = True
            logMessage("[ServiceScanUpdates] PARSER complete; services=%d transponders=%d" % (len(self.services), len(self.transponders)))
        except (ValueError, IndexError) as error:
            # Never compare a partial DB: that could report every channel removed.
            self.services = {}
            self.transponders = {}
            logMessage("[ServiceScanUpdates] Invalid database %s: %s" % (self.filename, error))

    # ===== Retrieve a service by reference =====
    def getServiceBySRef(self, service_ref):
        try:
            return self.services[service_ref]
        except Exception:
            return None

    # ===== Retrieve all services =====
    def getServices(self):
        return self.services

    # ===== Get service type from reference =====
    def getServiceName(self, service_ref):
        try:
            return self.services[service_ref]["service_name"]
        except Exception:
            return None

    @staticmethod
    def isVideoService(service_ref):
        service_type_str = str(service_ref.split(":")[2])
        if service_type_str:
            service_type = int(service_type_str, 16)
            logMessage("[ServiceScanUpdates] Check isVideoService [%s] (%d)" % (service_ref, service_type))
            # SD-Video or HD-Video
            return service_type in (1, 4, 5, 17, 22, 24, 25, 27, 31, 32)
        else:
            return False

    @staticmethod
    def isRadioService(service_ref):
        service_ref_str = str(service_ref.split(":")[2])
        if service_ref_str:
            service_type = int(service_ref_str, 16)
            logMessage("[ServiceScanUpdates] Check isRadioService [%s] (%d)" % (service_ref, service_type))
            # Radio
            return service_type in (2, 10)
        else:
            return False

    # ===== Check if service is data =====
    @staticmethod
    def isDataService(service_ref):
        service_ref_str = str(service_ref.split(":")[2])
        if service_ref_str:
            service_type = int(service_ref_str, 16)
            logMessage("[ServiceScanUpdates] Check isDataService [%s] (%d)" % (service_ref, service_type))
            # Data
            return service_type in (3, 12, 13, 14, 15, 16, 128, 129)
        else:
            return False

    # ===== Check if service has new flag =====
    @staticmethod
    def hasNewFlag(service_ref):
        return eDVBDB.getInstance().getFlag(eServiceReference(str(service_ref))) & FLAG_SERVICE_NEW_FOUND

    @staticmethod
    def getOrbitalPos(service_ref):
        try:
            while True:
                op = int(str(service_ref).split(":", 10)[6][:-4] or "0", 16)
                if op == 0xeeee:
                    result = "%s" % _("DVB-T")
                    break
                if op == 0xffff:
                    result = "%s" % _("DVB-C")
                    break

                direction = "E"
                if op > 1800:
                    op = 3600 - op
                    direction = "W"

                # Use ASCII-only orbital formatting to avoid encoding issues in bouquet files.
                result = "%d.%d%s" % (op // 10, op % 10, direction)
                break
        except Exception:
            result = "Unknown"
        logMessage("[ServiceScanUpdates] Orbital pos [%s] (%s)" % (str(service_ref), repr(result)))
        return result
